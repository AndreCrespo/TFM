/* USER CODE BEGIN Header */
/**
 *
 * EN ESTE CODIGO VOY A OBTENER EL PITCH Y EL ROLL SOLO USANDO EL ACC Y EL GYR
 *
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "RegMap_MPU9250.h"
#include "stdio.h"
#include "math.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */

//Necesario para usar el printf, seguir la guia para terminar de configurar el printf
int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart3, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint8_t dataW;
	uint8_t dataR[12] = {0,0,0,0,0,0,0,0,0,0,0,0};

	uint8_t id[1] = {0};

	//Medidas de los sensores
	float gyrX = 0, gyrY = 0, gyrZ = 0;
	float accX = 0, accY = 0, accZ = 0;

	//Medidas sin calibrar para realizar la calibracion
	uint8_t gyrRAW[6] = {0, 0, 0, 0, 0, 0};
	int16_t gyrRAWX = 0, gyrRAWY = 0, gyrRAWZ = 0;
	float sum_gyrRAWX = 0, sum_gyrRAWY = 0, sum_gyrRAWZ = 0;
	float gyrRAWX_Avg = 0, gyrRAWY_Avg = 0, gyrRAWZ_Avg = 0;

	//Medidas del angulo del acc
	float ang_acc_x = 0;
	float ang_acc_y = 0;

	//Medidas del angulo del gyr
	float ang_gyr_x = 0;
	float ang_gyr_y = 0;
	float ang_gyr_z = 0;

	float ang_gyr_x_def = 0;
	float ang_gyr_y_def = 0;
	float ang_gyr_z_def = 0;

	//Medidas de tiempo
	float current_time = 0;
	float previous_time = 0;
	float dt = 0;

	//Angulos filtro complementario
	float roll = 0;
	float pitch = 0;
	float yaw = 0;

	int counter = 0;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */

    //Escribimos en el registro de Power Management 1 para que haga un reset
    dataW = 0x80;
    HAL_I2C_Mem_Write(&hi2c1, MPU9250_ADDRESS, PWR_MGMT_1, 1, &dataW, 1, TIME_OUT_I2C);

    //Escribimos en el registro de Power Management 1 para que use el mejor clk
    dataW = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, MPU9250_ADDRESS, PWR_MGMT_1, 1, &dataW, 1, TIME_OUT_I2C);

  	//Compronamos que los id sean correctos
  	HAL_I2C_Mem_Read(&hi2c1, MPU9250_ADDRESS, WHO_AM_I_MPU9250, 1, &id[0], 1, TIME_OUT_I2C);

	//Escribimos en el registro de configuracion un 0, para no usar la FIFO,no usar el ext_sync
	//y ponemos la frecuencia de muestreo a 1 kHz con un BW de 92 para que coincida con la del acc
	dataW = 0x02;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_ADDRESS, CONFIG, 1, &dataW, 1, TIME_OUT_I2C);

	//Establecemos el FS del gyro a +-250dps(FS=00) y Fchoice_b a 00, para modificar la fs.
	dataW = 0x00;//FS<<3 por ser la versión invertida tengo que poner 0x00
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_ADDRESS, GYRO_CONFIG, 1, &dataW, 1, TIME_OUT_I2C);

	//Establecemos el FS del acc a +-2g (FS=0)
	dataW = 0x00;//FS<<3 por ser la versión invertida tengo que poner 0x00
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_ADDRESS, ACCEL_CONFIG, 1, &dataW, 1, TIME_OUT_I2C);
	//Como no vamos a variar la fs a 1 kHz para que coincida con la del gyro fs=1kHz y BW= 99
	dataW = 0x02;
	HAL_I2C_Mem_Write(&hi2c1, MPU9250_ADDRESS, ACCEL_CONFIG2, 1, &dataW, 1, TIME_OUT_I2C);

	//Funcion para comporar si el sensor esta operativo o no
	HAL_StatusTypeDef ok_IMU = HAL_I2C_IsDeviceReady(&hi2c1, MPU9250_ADDRESS, 5, TIME_OUT_I2C);
	if(ok_IMU==HAL_OK){
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
		HAL_Delay(2000);
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
	}

	//Calibrado del gyro, DEJAR EL SENSOR QUIETO
		//printf("Calibrado del gyro, DEJAR EL SENSOR QUIETO\r\n");
		HAL_Delay(500);
		for(int i = 0; i<50; i++){
			HAL_I2C_Mem_Read(&hi2c1, MPU9250_ADDRESS, GYRO_XOUT_H, 1, &gyrRAW[0], 6, TIME_OUT_I2C);
			gyrRAWX = (gyrRAW[0]<<8|gyrRAW[1]);
			gyrRAWY = (gyrRAW[2]<<8|gyrRAW[3]);
			gyrRAWZ = (gyrRAW[4]<<8|gyrRAW[5]);

			//Sumatorio
			sum_gyrRAWX += gyrRAWX;
			sum_gyrRAWY += gyrRAWY;
			sum_gyrRAWZ += gyrRAWZ;

			HAL_Delay(2);
		}

		//Media
		gyrRAWX_Avg = sum_gyrRAWX/2000;
		gyrRAWY_Avg = sum_gyrRAWY/2000;
		gyrRAWZ_Avg = sum_gyrRAWZ/2000;
		//printf("FIN Calibrado del gyro\r\n");

		previous_time = HAL_GetTick();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	 //Medidos los datos del acc
	 HAL_I2C_Mem_Read(&hi2c1, MPU9250_ADDRESS, ACCEL_XOUT_H, 1, &dataR[6], 6, TIME_OUT_I2C);

	 accX = (int16_t)(dataR[6]<<8|dataR[7])/16384.0;
	 accY = (int16_t)(dataR[8]<<8|dataR[9])/16384.0;
	 accZ = (int16_t)(dataR[10]<<8|dataR[11])/16384.0;

	 //Medidmos los angulos acc
	 ang_acc_x = atan(accY / sqrt(pow(accX , 2) + pow(accZ , 2)))*(180/PI);
	 ang_acc_y = atan(-accX / sqrt(pow(accY , 2) + pow(accZ , 2)))*(180/PI);

	 current_time = HAL_GetTick();
	 dt = (current_time - previous_time)/1000;

    //Medidos los datos del gyr
    HAL_I2C_Mem_Read(&hi2c1, MPU9250_ADDRESS, GYRO_XOUT_H, 1, &dataR[0], 6, TIME_OUT_I2C);

	gyrX = (int16_t)(dataR[0]<<8|dataR[1]);
	gyrY = (int16_t)(dataR[2]<<8|dataR[3]);
	gyrZ = (int16_t)(dataR[4]<<8|dataR[5]);

	//Corregimos las medidas del gyr
	gyrX = (gyrX - gyrRAWX_Avg)/131.0;
	gyrY = (gyrY - gyrRAWY_Avg)/131.0;
	gyrZ = (gyrZ - gyrRAWZ_Avg)/131.0;


	//dt = (current_time - previous_time)/1000.0;
	//previous_time = HAL_GetTick()+500;
	previous_time = current_time;

	//Medimos los angulos del gyr RAROS
	ang_gyr_x = ang_gyr_x + gyrX*dt;
	ang_gyr_y = ang_gyr_y + gyrY*dt;// si pongo ang_gyr_y => va creciendo si pongo pitch no
	ang_gyr_z = ang_gyr_z + gyrZ*dt;

	//Medimos los angulos del gyr
	ang_gyr_x_def = (gyrX*dt) + roll;
	ang_gyr_y_def = (gyrY*dt) + pitch;
	ang_gyr_z_def = (gyrZ*dt) + ang_gyr_z_def;

	roll = 0.95*ang_gyr_x_def + 0.05*ang_acc_x;
	pitch = 0.95*ang_gyr_y_def + 0.05*ang_acc_y;//antes tenia lo de de roll y pitch e iba mejor
	// tambien tenia los valolres de 0.6 y 0.4
	//yaw = ang_gyr_z;

	if(counter - 50==0){
		counter = 0;
		//printf("ACC_roll: %f\r\n", ang_acc_x);
		printf("ACC_pitch: %f , ", ang_acc_y  );
		//printf("GYR_roll: %f\r\n", ang_gyr_x);
		printf("GYR_pitch: %f , ", ang_gyr_y  );
		//printf("GYR_yaw: %f\r\n", ang_gyr_z);
		//printf("roll: %f\r\n", roll);
		printf("pitch: %f\r\n", pitch  );

		printf("ACC_roll: %f , ", ang_acc_x);
		printf("GYR_roll: %f , ", ang_gyr_x);
		printf("roll: %f\r\n", roll);
	}
	counter = counter + 1;


	//HAL_Delay(500);


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLL_DIV3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 230400;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
